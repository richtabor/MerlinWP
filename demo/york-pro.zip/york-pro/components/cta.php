<?php
/**
 *  The footer Call to Action
 *
 * @package York Pro
 * @version 2.0.4
 * @author  ThemeBeans <hello@themebeans.com>
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 */

if ( ! is_home() or is_page_template( 'template-portfolio' ) or is_search() or is_archive() ) :

	$visibility = ( false === get_theme_mod( 'york_footer_cta', true ) ) ? 'hidden' : ''; ?>

	<div class="cta-spacer <?php echo esc_html( $visibility ); ?>"></div>
			
	<footer class="cta animsition <?php echo esc_html( $visibility ); ?>">

		<div class="cta-wrapper">
			<div class="cta-wrapper-inner">

				<?php
				if ( get_theme_mod( 'york_footer_cta_text1', true ) ) :
					printf( '<h2 class="intro-text">%1$s</h2>', esc_html( get_theme_mod( 'york_footer_cta_text1', esc_html__( 'Have a cool project?', 'york-pro' ) ) ) );
				endif;

				if ( get_theme_mod( 'york_footer_cta_text2', true ) ) :
					printf( '<h2 class="lets-chat"><i>%1$s</i></h2>', esc_html( get_theme_mod( 'york_footer_cta_text2', esc_html__( 'Then lets chat!', 'york-pro' ) ) ) );
				endif; ?>
			</div>
		</div>

		<?php if ( get_theme_mod( 'york_footer_cta_link', 'https://themebeans.com' ) ) :

			$target = ( true === get_theme_mod( 'york_footer_cta_link_target', true ) ) ? 'target="_blank"' : '';

			printf( '<a href="%1$s" class="cta-link" %2$s alt=""></a>',
				esc_url( get_theme_mod( 'york_footer_cta_link', 'https://themebeans.com' ) ),
				esc_attr( $target )
			);

		endif; ?>

		<?php if ( get_theme_mod( 'york_footer_cta_shapes', true ) ) : ?>
			<?php get_template_part( 'components/shapes' ); ?>
		<?php endif; ?>

	</footer>

<?php endif;
