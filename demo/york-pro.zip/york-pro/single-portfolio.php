<?php
/**
 * The template for displaying the single portfolio posts.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package York Pro
 * @version 2.0.4
 * @author  ThemeBeans <hello@themebeans.com>
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 */

get_header();

// Start the loop.
while ( have_posts() ) : the_post();

	// Include the single post and single portfolio content template.
	get_template_part( 'components/portfolio/single' );

	// Include Photoswipe on single portfolio pages.
	if ( true === get_theme_mod( 'york_portfolio_lightbox', true ) ) {
		get_template_part( 'components/portfolio/photoswipe' );
	}

endwhile;

get_footer();
