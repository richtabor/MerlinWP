<?php
/**
 * The template for displaying portfolio category pages
 *
 * Used to display archive-type pages for portfolio posts.
 * If you'd like to further customize these taxonomy views, you may create a
 * new template file for each specific one.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package York Pro
 * @version 2.0.4
 * @author  ThemeBeans <hello@themebeans.com>
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 */

get_header();

get_template_part( 'components/portfolio/portfolio' );

get_footer();
