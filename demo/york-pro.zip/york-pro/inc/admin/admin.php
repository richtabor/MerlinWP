<?php
/**
 * Load admin functionalities
 *
 * ThemeBeans Core: v1.1.0
 *
 * @package York Pro
 * @version 2.0.4
 * @author  ThemeBeans <hello@themebeans.com>
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 */

/**
 * Load admin related functions.
 */
require get_parent_theme_file_path( '/inc/admin/functions.php' );

/**
 * Recommended and required plugins.
 */
require get_parent_theme_file_path( '/inc/plugins.php' );
require get_parent_theme_file_path( '/inc/admin/tgmpa/class-tgm-plugin-activation.php' );

/**
 * This theme only works in WordPress 4.7 or later.
 */
if ( version_compare( $GLOBALS['wp_version'], '4.7', '<' ) ) {
	require get_parent_theme_file_path( '/inc/admin/back-compat.php' );
}

/**
 * Load dashboard notifications.
 */
function themebeans_notices() {
	require get_parent_theme_file_path( '/inc/admin/notices/club.php' );
}
add_action( 'after_setup_theme', 'themebeans_notices' );

/**
 * Theme Updater.
 */
function themebeans_updater() {
	require get_parent_theme_file_path( '/inc/admin/updater/updater-admin.php' );
	require get_parent_theme_file_path( '/inc/admin/updater/updater.php' );
}
add_action( 'after_setup_theme', 'themebeans_updater' );

/**
 * Dashboard Guide.
 */
function themebeans_guide() {
	require get_parent_theme_file_path( '/inc/admin/guide/huh.php' );
}
add_action( 'after_setup_theme', 'themebeans_guide' );

/**
 * Merlin WP.
 */
function themebeans_merlin() {
	require get_parent_theme_file_path( '/inc/admin/merlin/merlin.php' );
	require get_parent_theme_file_path( '/inc/admin/merlin-config.php' );
}
add_action( 'after_setup_theme', 'themebeans_merlin' );
