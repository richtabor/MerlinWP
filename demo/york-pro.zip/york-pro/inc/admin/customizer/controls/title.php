<?php
/**
 * Title Customizer Control
 *
 * @see https://developer.wordpress.org/reference/classes/wp_customize_control/
 *
 * @package York Pro
 * @version 2.0.4
 * @author  ThemeBeans <hello@themebeans.com>
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 */

/**
 * Custom Title Control
 */
class ThemeBeans_Title_Control extends WP_Customize_Control {
	/**
	 * Set the control type.
	 *
	 * @var $type Customizer type
	 */
	public $type = 'custom_title';

	/**
	 * Render the content.
	 *
	 * @see https://developer.wordpress.org/reference/classes/wp_customize_control/render_content/
	 */
	public function render_content() {

		if ( isset( $this->label ) ) {
			echo '<span class="customize-control-title">' . esc_html( $this->label ) . '</span>';
		}

		if ( ! empty( $this->description ) ) {
			echo '<div class="customize-control-tooltip-wrapper"><span class="customize-control-tooltip hint hint--top" data-hint="' . esc_html( $this->description ) . '"><span class="customize-control-tooltip-icon"></span></span></div>';
		}

	}
}
