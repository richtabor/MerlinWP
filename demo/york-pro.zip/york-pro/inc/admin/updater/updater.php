<?php
/**
 * EDD Theme Updater
 *
 * @package York Pro
 * @version 2.0.4
 * @author  ThemeBeans <hello@themebeans.com>
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 */

$updater = new EDD_Theme_Updater_Admin(

	$config = array(
		'remote_api_url'    => 'https://themebeans.com',
		'item_name'         => esc_attr( themebeans_get_theme( false ) ),
		'theme_slug'        => esc_attr( themebeans_get_theme( true ) ),
		'version'           => esc_attr( wp_get_theme( get_template() )->get( 'Version' ) ),
		'author'            => 'ThemeBeans',
		'download_id'       => '105665',
		'renew_url'         => '',
	),
	$strings = array(
		'license-unknown'           => esc_html__( 'Unknown license. Please contact support at support@themebeans.com and we will sort this out for you.' , 'york-pro' ),
		'theme-license'             => esc_html__( 'Activate your theme license.', 'york-pro' ),
		'enter-key'                 => wp_kses( __( 'Add your license key to get theme updates without leaving your dashboard and to access support. Locate your license key in your ThemeBeans account dashboard and on your purchase receipt.<br><br>Enter your license key below:', 'york-pro' ), array( 'br' => array() ) ),
		'license-key'               => esc_html__( 'License Key', 'york-pro' ),
		'license-action'            => esc_html__( 'License Action', 'york-pro' ),
		'enter-license-label'       => esc_html__( '', 'york-pro' ),
		'deactivate-license'        => esc_html__( 'Deactivate License', 'york-pro' ),
		'reload-button'             => esc_html__( 'Reload', 'york-pro' ),
		'activate-license'          => esc_html__( 'Activate License', 'york-pro' ),
		'reactivate-button'         => esc_html__( 'Reactivate License', 'york-pro' ),
		'status-unknown'            => esc_html__( 'License status is unknown.', 'york-pro' ),
		'renew'                     => esc_html__( 'renew your theme license.', 'york-pro' ),
		'renew-after'               => esc_html__( 'After completing the renewal, click the Reload button below.', 'york-pro' ),
		'renew-button'              => esc_html__( 'Renew your License &rarr;', 'york-pro' ),
		'unlimited'                 => esc_html__( 'unlimited', 'york-pro' ),
		'license-key-is-active%s'   => esc_html__( 'Seamless theme updates and support has been enabled for %s. You will receive a notice in your dashboard when an update is available.', 'york-pro' ),
		'expires%s'                 => esc_html__( '', 'york-pro' ),
		'%1$s/%2$-sites'            => esc_html__( 'You have %1$s / %2$s sites activated.', 'york-pro' ),
		'license-key-expired-%s'    => esc_html__( 'Your license key expired on %s. In order to access support and seamless updates, you need to', 'york-pro' ),
		'license-key-expired'       => esc_html__( 'License key has expired.', 'york-pro' ),
		'license-keys-do-not-match' => esc_html__( 'This is not a valid license key. Please try again.', 'york-pro' ),
		'license-is-inactive'       => esc_html__( 'License is inactive.', 'york-pro' ),
		'license-key-is-disabled'   => esc_html__( 'License key is disabled.', 'york-pro' ),
		'site-is-inactive'          => esc_html__( 'Site is inactive.', 'york-pro' ),
		'license-status-unknown'    => esc_html__( 'License status is unknown.', 'york-pro' ),
		'update-notice'             => esc_html__( "Updating this theme will lose any customizations you have made. 'Cancel' to stop, 'OK' to update.", 'york-pro' ),
		'update-available'          => __( '<strong>%1$s %2$s</strong> is available. <a href="%3$s" title="%4s" target="blank">Check out what\'s new</a> or <a href="%5$s" %6$s>update now</a>', 'york-pro' ),
	)
);
