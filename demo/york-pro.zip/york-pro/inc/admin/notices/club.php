<?php
/**
 * Theme Club notification class.
 * Prompt users to check out the Theme Club after a week with the current theme.
 * Currently only notifies users who have activated their theme license and
 * have an active subscription, that is not the Club subscription. It does not show up for
 * Lifetime Club members, because it's not a subscription — and we check for a lifetime expiration date.
 *
 * @package York Pro
 * @version 2.0.4
 * @author  ThemeBeans <hello@themebeans.com>
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 */

if ( ! class_exists( 'ThemeBeans_Club_Notice' ) ) :
	/**
	 * Main ThemeBeans_Club_Notice Class.
	 *
	 * @since 1.0.0
	 */
	class ThemeBeans_Club_Notice {

		/**
		 * Theme slug.
		 *
		 * @var slug | Current theme's slug.
		 * @since 1.0.0
		 */
		private $slug;

		/**
		 * Theme name.
		 *
		 * @var name | Current theme's name.
		 * @since 1.0.0
		 */
		private $name;

		/**
		 * Time.
		 *
		 * @var time_limit | The time for the notification to display.
		 * @since 1.0.0
		 */
		private $time_limit;

		/**
		 * No bug.
		 *
		 * @var nobug_option | The option to hide the notification.
		 * @since 1.0.0
		 */
		public $nobug_option;

		/**
		 * The API URL of the site we're sending the update request to.
		 *
		 * @var string $remote_api_url
		 */
		private $remote_api_url;

		/**
		 * Customer email.
		 *
		 * @var string $email
		 */
		private $email;

		/**
		 * Subscription data.
		 *
		 * @var string $subscription
		 */
		private $subscription;

		/**
		 * Fire the constructor up :)
		 *
		 * @param array $args | An array of custom-background support arguments.
		 */
		public function __construct( $args ) {

			// Variables.
			$this->slug 					= $args['slug'];
			$this->name 					= $args['name'];
			$this->remote_api_url 			= 'https://themebeans.com';
			$this->nobug_option 			= $this->slug . '-no-bug';

			// Define the transient slugs.
			$transient_slug 				= themebeans_get_theme( true ) . '_' . $this->slug . '_';
			$this->transient_email 			= strtolower( $transient_slug . 'email' );
			$this->transient_subscription 	= strtolower( $transient_slug . 'subscription' );

			// When do we display the notice?
			if ( isset( $args['time_limit'] ) ) {
				$this->time_limit  = $args['time_limit'];
			} else {
				$this->time_limit = WEEK_IN_SECONDS;
			}

			// Load the main functionality.
			$slug 			= esc_attr( themebeans_get_theme( true ) );
			$license 		= trim( get_option( $slug . '_license_key' ) );

			// if ( true == get_site_option( $this->nobug_option ) ) {
			// 	return;
			// }

			if (  $license ) {
				add_action( 'admin_init', array( $this, 'check_installation_date' ) );
				add_action( 'admin_init', array( $this, 'set_no_bug' ), 5 );
				add_filter( 'admin_init', array( $this, 'email_transient' ) );
				add_filter( 'admin_init', array( $this, 'subscription_transient' ) );
				add_action( 'admin_enqueue_scripts', array( $this, 'load_scripts' ) );
			}

		}

		/**
		 * Enqueue CSS and JS.
		 */
		public function load_scripts() {

			global $pagenow;

			// This is a ThemeBeans Club member already, so there's no need to show this to them.
			if ( $this->is_club_member() == false ) {
				return;
			}

			if ( true == get_site_option( $this->nobug_option ) ) {
				return;
			}

			if ( current_user_can( 'manage_options' ) ) {

				if ( ( 'index.php' == $pagenow ) ) {
	    			wp_register_style( 'club-notification-css', get_parent_theme_file_uri( '/inc/admin/notices/club.css' ), false );
	    			wp_enqueue_style( 'club-notification-css' );
	    		}
	        }
		}

		/**
		 * Add an update transient.
		 *
		 * @param string $value Transient.
		 */
		function email_transient( $value ) {
			$update_data = $this->get_email();
			if ( $update_data ) {
				$value->response[ $this->email ] = $update_data;
			}
			return $value;
		}

		/**
		 * Add another update transient.
		 *
		 * @param string $value Transient.
		 */
		function subscription_transient( $value ) {
			$update_data = $this->get_subscription();
			if ( $update_data ) {
				$value->response[ $this->subscription ] = $update_data;
			}
			return $value;
		}

		/**
		 * Get the licensed user's email address.
		 *
		 * No active subscriptions license: a626c1967ac3142fb43093cbdd2fee72
		 * Active subscription test: b99658bd51090c5cf6db3dda0b7d50dd
		 * Club subscription test: 2d7c32abaac830a956550781c1b08ef2
		 */
		public function get_email() {

			$slug 			= esc_attr( themebeans_get_theme( true ) );
			$license 		= trim( get_option( $slug . '_license_key' ) );
			$item_name 		= esc_attr( themebeans_get_theme( false ) );

			if ( ! $license ) {
				return false;
			}

			$update_data = get_transient( $this->transient_email );

			if ( false === $update_data ) {

				$failed = false;

				$api_params = array(
					'edd_action'    => 'check_license',
					'license'   	=> $license,
					'item_name'     => $item_name,
				);

				$response = wp_remote_post( $this->remote_api_url, array( 'timeout' => 15, 'body' => $api_params ) );

				// Make sure the response was successful.
				if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
					$failed = true;
				}

				$update_data = json_decode( wp_remote_retrieve_body( $response ) );

				if ( ! is_object( $update_data ) ) {
					$failed = true;
				}

				// If the response failed, try again in 30 minutes.
				if ( $failed ) {
					$data = new stdClass;
					set_transient( $this->transient_email , $data, strtotime( '+30 minutes' ) );
					return false;
				}

				// If the status is 'ok', return the update arguments.
				if ( ! $failed ) {
					set_transient( $this->transient_email , $update_data, MONTH_IN_SECONDS );
				}
			}

			return (array) $update_data;
		}

		/**
		 * Get the licensed user's email address.
		 */
		public function get_subscription() {

			$api_response 	= get_transient( $this->transient_email );
			$email 			= $api_response->customer_email;

			// Only continue if we have an email address from license activation. There's no point checking for subscriptions, if it's not active.
			if ( ! $email ) {
				return true;
			}

			// Let's get a transient for the subscription check.
			$update_data = get_transient( $this->transient_subscription );

			if ( false === $update_data ) {

				$failed = false;

				$api_params = array(
					'key'    		=> 'f92dfce0ecbbada11bed8b0785c55b0f',
					'token'   		=> 'cf02fe56acfe6a2268c42d47f9ee03b1',
					'customer'      => $email,
				);

				$response = wp_remote_post( $this->remote_api_url . '/edd-api/subscriptions/' , array( 'timeout' => 15, 'body' => $api_params ) );

				// Make sure the response was successful.
				if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
					$failed = true;
				}

				$update_data = json_decode( wp_remote_retrieve_body( $response ), true );

				// If the response failed, try again in 30 minutes.
				if ( $failed ) {
					$data = new stdClass;
					set_transient( $this->transient_subscription, $data, strtotime( '+30 minutes' ) );
					return false;
				}

				// If the status is 'ok', return the update arguments.
				if ( ! $failed ) {
					set_transient( $this->transient_subscription, $update_data, MONTH_IN_SECONDS );
				}
			}

			return (array) $update_data;
		}

		/**
		 * Check if this user has purchased a Club Membership (Download ID: 110096 & 139343 ).
		 */
		public function is_club_member() {

			$email 				= null;
			$expires 			= null;

			$email_api 			= get_transient( $this->transient_email );
			$subscription_api 	= get_transient( $this->transient_subscription );

			if ( $email_api ) {
				$email 			= $email_api->customer_email;
				$expires 		= $email_api->expires;
			}

			if ( 'lifetime' == $expires ) {
				return false;
			}

			// Uncomment this to output the response: print_r( $subscription_api ); or print_r( $email_api );
			// Check if there's an error, which likely means there's no subscription found.
			if ( $subscription_api && ! array_key_exists( 'error', $subscription_api ) ) {

				// If it's a valid subscription.
				$product_id 	= $subscription_api['subscriptions'][0]['info']['product_id'];
				$status 		= $subscription_api['subscriptions'][0]['info']['status'];

			} else {
				// If it's not a valid subscription.
				$product_id 	= 'no-product-found';
				$status 		= 'no-status-found';
			}

			// Uncomment below to test the output.
			// echo 'Email: ';
			// echo esc_html( $email );
			// echo '&nbsp;';
			// echo 'Product ID: ';
			// echo esc_html( $product_id );
			// echo '&nbsp;';
			// echo ' Status: ';
			// echo esc_html( $status );
			// echo get_site_option( $this->nobug_option );
			// // Now let's see if the current subscription is a Club Member subscription, and it is not expired.
			if ( '110096' !== $product_id and 'active' === $status ) {
				return true;
			}
		}

		/**
		 * Convert seconds to relative text.
		 *
		 * @param string $seconds | Time in seconds, based on when the current theme was activated.
		 */
		public function seconds_to_words( $seconds ) {

			// Get the years.
			$years = ( intval( $seconds ) / YEAR_IN_SECONDS ) % 100;
			if ( $years > 1 ) {
				return sprintf( esc_html__( '%s years', 'york-pro' ), $years );
			} elseif ( $years > 0 ) {
				return esc_html__( 'a year', 'york-pro' );
			}

			// Get the weeks.
			$weeks = ( intval( $seconds ) / WEEK_IN_SECONDS ) % 52;
			if ( $weeks > 1 ) {
				return sprintf( esc_html__( '%s weeks', 'york-pro' ), $weeks );
			} elseif ( $weeks > 0 ) {
				return esc_html__( 'a week', 'york-pro' );
			}

			// Get the days.
			$days = ( intval( $seconds ) / DAY_IN_SECONDS ) % 7;
			if ( $days > 1 ) {
				return sprintf( esc_html__( '%s days', 'york-pro' ), $days );
			} elseif ( $days > 0 ) {
				return esc_html__( 'a day', 'york-pro' );
			}

			// Get the hours.
			$hours = ( intval( $seconds ) / HOUR_IN_SECONDS ) % 24;
			if ( $hours > 1 ) {
				return sprintf( esc_html__( '%s hours', 'york-pro' ), $hours );
			} elseif ( $hours > 0 ) {
				return esc_html__( 'an hour', 'york-pro' );
			}

			// Get the minutes.
			$minutes = ( intval( $seconds ) / MINUTE_IN_SECONDS ) % 60;
			if ( $minutes > 1 ) {
				return sprintf( esc_html__( '%s minutes', 'york-pro' ), $minutes );
			} elseif ( $minutes > 0 ) {
				return esc_html__( 'a minute', 'york-pro' );
			}

			// Get the seconds.
			$seconds = intval( $seconds ) % 60;
			if ( $seconds > 1 ) {
				return sprintf( esc_html__( '%s seconds', 'york-pro' ), $seconds );
			} elseif ( $seconds > 0 ) {
				return esc_html__( 'a second', 'york-pro' );
			}

			return;
		}

		/**
		 * Check date on admin initiation and add to admin notice if it was more than the time limit.
		 */
		public function check_installation_date() {

			if ( true != get_site_option( $this->nobug_option ) ) {
				// If not installation date set, then add it.
				$install_date = get_site_option( $this->slug . '-activation-date' );
				if ( '' == $install_date ) {
					add_site_option( $this->slug . '-activation-date', time() );
				}
				// If difference between install date and now is greater than time limit, then display notice.
				if ( ( time() - $install_date ) > $this->time_limit ) {

					if ( $this->is_club_member() == true ) {
						add_action( 'admin_notices', array( $this, 'display_admin_notice' ) );
					}
				}
			}
		}

		/**
		 * Display the notice.
		 */
		public function display_admin_notice() {

			global $pagenow;

			// This is a ThemeBeans Club member already, so there's no need to show this to them.
			if ( $this->is_club_member() == false ) {
				return;
			}

			if ( current_user_can( 'manage_options' ) ) {

				if ( ( 'index.php' == $pagenow ) ) {

					$no_bug_url = wp_nonce_url( admin_url( '?' . $this->nobug_option . '=true' ), 'club-nonce' ); ?>

					<div class="welcome-panel club-notice">
						<div class="welcome-panel-content">
							<div class="content__left">
								<h2><?php echo sprintf( esc_html__( 'Join the %s Club. Save %s.', 'york-pro' ), 'ThemeBeans', '50%' ); ?></h2>
								<p><?php printf( esc_html__( 'Download every beautiful WordPress theme in our entire catalog, plus any WordPress themes launched in the next year, for a limited time upgrade of %s.', 'york-pro' ), '$49' ); ?></p>
								<p>
									<a class="button button-primary" href="<?php echo esc_url( 'https://themebeans.com/?edd_action=themebeans_empty_cart_add_club_upgrade' ); ?>" target="_blank"><?php echo esc_html__( 'Upgrade Now', 'york-pro' )?></a>
									<a class="button button-secondary" href="<?php echo esc_url( 'https://themebeans.com/pricing/?upgrade=true' ); ?>" target="_blank"><?php echo esc_html__( 'Learn More', 'york-pro' );?></a>
									<a class="welcome-panel-close" href="<?php echo esc_url( $no_bug_url ); ?>"><?php echo esc_html__( 'Dismiss', 'york-pro' )?></a>
								</p>
							</div>
						</div>
						<figure class="club"><div></div></figure>
					</div>

				<?php
				}
			}
		}

		/**
		 * Set the notice to no longer bug users if user asks not to be.
		 */
		public function set_no_bug() {

			// Bail out if not on correct page.
			if ( ! isset( $_GET['_wpnonce'] ) || (
				! wp_verify_nonce( $_GET['_wpnonce'], 'club-nonce' ) ||
				! is_admin() ||
				! isset( $_GET[ $this->nobug_option ] ) ||
				! current_user_can( 'manage_options' )
				)
			) {
				return;
			}

			add_site_option( $this->nobug_option, true );
		}
	}

endif; // End if class_exists check.

/**
 * Set the variables for the feedback class
 */
new ThemeBeans_Club_Notice( array(
	'slug'        => 'themebeans_club',
	'name'        => themebeans_get_theme( false ),
	'time_limit'  => WEEK_IN_SECONDS,
) );
