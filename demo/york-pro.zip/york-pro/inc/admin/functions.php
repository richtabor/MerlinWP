<?php
/**
 * Dashboard functions
 *
 * @package York Pro
 * @version 2.0.4
 * @author  ThemeBeans <hello@themebeans.com>
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 */

/**
 * Theme changelog in footer admin.
 *
 * @param boolean $url URL or not.
 */
function themebeans_get_theme( $url ) {

	// Get the parent theme's name.
	$theme = esc_attr( wp_get_theme( get_template() )->get( 'Name' ) );

	// Replace spaces with hypens, and makes it lowercase for links.
	if ( true === $url ) {
		$theme  = strtolower( $theme );
		$theme  = str_replace( ' ', '-', $theme );
		$theme  = preg_replace( '#[ -]+#', '-', $theme );
	}

	return $theme;
}

/**
 * Add the theme version to the front end.
 */
function themebeans_meta_tag() {

	// Get the parent theme's name.
	$theme = themebeans_get_theme( false );

	// Get the parent theme's current version number.
	$version = wp_get_theme( get_template() )->get( 'Version' );

	echo '<meta name="generator" content="'. esc_attr( $theme ) .' v'. esc_attr( $version ) .'" />'."\n";
}
add_action( 'wp_head', 'themebeans_meta_tag', 0 );

/**
 * Theme changelog in footer admin.
 */
function themebeans_dashboard_link() {

	global $submenu;

	$submenu['index.php'][500] = array( 'ThemeBeans', 'manage_options' , 'https://themebeans.com/?utm_source=Admin%20Dashboard%20Link&utm_medium=wp-admin-link&utm_campaign=WP%20Dashboard%20Link&utm_content='.esc_attr( themebeans_get_theme( true ) ).'' );

}
add_action( 'admin_menu' , 'themebeans_dashboard_link' );

/**
 * Theme changelog in footer admin.
 *
 * @param string $html WordPress version.
 */
function themebeans_dashboard_footer_version( $html ) {

	// Get the parent theme's current version number.
	$version  = wp_get_theme( get_template() )->get( 'Version' );

	$html   .= ' | <a href="http://demo.themebeans.com/wp-content/themes/' . esc_attr( themebeans_get_theme( true ) ) . '/changelog.txt" target="_blank">' . esc_html( themebeans_get_theme( false ) .'&nbsp;'. $version ) . '</a>';

	return $html;

}
add_filter( 'update_footer', 'themebeans_dashboard_footer_version', 12 );

/**
 * Dashboard help guide.
 */
function themebeans_theme_guide() {

	if ( ! class_exists( 'WP_Huh' ) ) {
		return;
	}

	$markdown_url = 'https://raw.githubusercontent.com/richtabor/theme-docs/master/'.esc_attr( themebeans_get_theme( true ) ).'/readme.md';

	$huh = new WP_Huh();
	$huh->init( $markdown_url );

}
add_action( 'admin_init', 'themebeans_theme_guide' );
