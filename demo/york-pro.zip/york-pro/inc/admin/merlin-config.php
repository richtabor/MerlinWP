<?php
/**
 * Merlin WP configuration file.
 *
 * @package York Pro
 * @version 2.0.4
 * @author  ThemeBeans <hello@themebeans.com>
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 */

if ( ! class_exists( 'Merlin' ) ) {
	return;
}

/**
 * Set directory locations, text strings, and other settings for Merlin WP.
 */
$wizard = new Merlin(
	// Configure Merlin with custom settings.
	$config = array(
		'directory'			=> 'inc/admin/',				// Location where the 'merlin' directory is placed.
		'demo_directory'		=> 'inc/demo/',					// Location where the theme demo files exist.
		'merlin_url'			=> 'merlin',					// Customize the page URL where Merlin WP loads.
		'child_action_btn_url'		=> 'https://codex.wordpress.org/Child_Themes',  // The URL for the 'child-action-link'.
		'help_mode'			=> false,					// Set to true to turn on the little wizard helper.
		'dev_mode'			=> false,					// Set to true if you're testing or developing.
		'branding'			=> false,					// Set to false to remove Merlin WP's branding.
	),
	// Text strings.
	$strings = array(
		'admin-menu' 			=> esc_html__( 'Theme Setup' , 'york-pro' ),
		'title%s%s%s%s' 		=> esc_html__( '%s%s Themes &lsaquo; Theme Setup: %s%s' , 'york-pro' ),

		'return-to-dashboard' 		=> esc_html__( 'Return to the dashboard' , 'york-pro' ),

		'btn-skip' 			=> esc_html__( 'Skip' , 'york-pro' ),
		'btn-next' 			=> esc_html__( 'Next' , 'york-pro' ),
		'btn-start' 			=> esc_html__( 'Start' , 'york-pro' ),
		'btn-no' 			=> esc_html__( 'Cancel' , 'york-pro' ),
		'btn-plugins-install' 		=> esc_html__( 'Install' , 'york-pro' ),
		'btn-child-install' 		=> esc_html__( 'Install' , 'york-pro' ),
		'btn-content-install' 		=> esc_html__( 'Install' , 'york-pro' ),
		'btn-import' 			=> esc_html__( 'Import' , 'york-pro' ),
		'btn-license-activate' 		=> esc_html__( 'Activate' , 'york-pro' ),

		'welcome-header%s' 		=> esc_html__( 'Welcome to %s' , 'york-pro' ),
		'welcome-header-success%s' 	=> esc_html__( 'Hi. Welcome back' , 'york-pro' ),
		'welcome%s' 			=> esc_html__( 'This wizard will set up your theme, install plugins, and import content. It is optional & should take only a few minutes.' , 'york-pro' ),
		'welcome-success%s' 		=> esc_html__( 'You may have already run this theme setup wizard. If you would like to proceed anyway, click on the "Start" button below.' , 'york-pro' ),

		'child-header' 			=> esc_html__( 'Install Child Theme' , 'york-pro' ),
		'child-header-success' 		=> esc_html__( 'You\'re good to go!' , 'york-pro' ),
		'child' 			=> esc_html__( 'Let’s build & activate a child theme so you may easily make theme changes.' , 'york-pro' ),
		'child-success%s' 		=> esc_html__( 'Your child theme has already been installed and is now activated — if it wasn\'t already.' , 'york-pro' ),
		'child-action-link' 		=> esc_html__( 'Learn about child themes' , 'york-pro' ),
		'child-json-success%s' 		=> esc_html__( 'Awesome. Your child theme has already been installed and is now activated.' , 'york-pro' ),
		'child-json-already%s' 		=> esc_html__( 'Awesome. Your child theme has been created and is now activated.' , 'york-pro' ),

		'plugins-header' 		=> esc_html__( 'Install Plugins' , 'york-pro' ),
		'plugins-header-success' 	=> esc_html__( 'You\'re up to speed!' , 'york-pro' ),
		'plugins' 			=> esc_html__( 'Let’s install some essential WordPress plugins to get your site up to speed.' , 'york-pro' ),
		'plugins-success%s' 		=> esc_html__( 'The required WordPress plugins are all installed and up to date. Press "Next" to continue the setup wizard.' , 'york-pro' ),
		'plugins-action-link' 		=> esc_html__( 'Advanced' , 'york-pro' ),

		'import-header' 		=> esc_html__( 'Import Content' , 'york-pro' ),
		'import' 			=> esc_html__( 'Let’s import content to your website, to help you get familiar with the theme.' , 'york-pro' ),
		'import-action-link' 		=> esc_html__( 'Advanced' , 'york-pro' ),

		'license-header%s' 		=> esc_html__( 'Activate %s' , 'york-pro' ),
		'license' 			=> esc_html__( 'Add your license key to activate one-click updates and theme support.' , 'york-pro' ),
		'license-action-link' 		=> esc_html__( 'More info' , 'york-pro' ),

		'license-link-1'            	=> wp_kses( sprintf( __( '<a href="https://wordpress.org/support/" target="_blank">%s</a>', 'york-pro' ), 'Explore WordPress' ), array( 'a' => array( 'href' => array(), 'target' => array() ) ) ),
		'license-link-2'            	=> wp_kses( sprintf( __( '<a href="https://themebeans.com/contact/" target="_blank">%s</a>', 'york-pro' ), 'Get Theme Support' ), array( 'a' => array( 'href' => array(), 'target' => array() ) ) ),
		'license-link-3'           	=> wp_kses( sprintf( __( '<a href="'.admin_url( 'customize.php' ).'" target="_blank">%s</a>', 'york-pro' ), 'Start Customizing' ), array( 'a' => array( 'href' => array(), 'target' => array() ) ) ),

		'ready-header' 			=> esc_html__( 'All done. Have fun!' , 'york-pro' ),
		'ready%s' 			=> esc_html__( 'Your theme has been all set up. Enjoy your new theme by %s.' , 'york-pro' ),
		'ready-action-link' 		=> esc_html__( 'Extras' , 'york-pro' ),
		'ready-big-button' 		=> esc_html__( 'View your website' , 'york-pro' ),

		'ready-link-1'              	=> wp_kses( sprintf( __( '<a href="https://wordpress.org/support/" target="_blank">%s</a>', 'york-pro' ), 'Explore WordPress' ), array( 'a' => array( 'href' => array(), 'target' => array() ) ) ),
		'ready-link-2'              	=> wp_kses( sprintf( __( '<a href="https://themebeans.com/contact/" target="_blank">%s</a>', 'york-pro' ), 'Get Theme Support' ), array( 'a' => array( 'href' => array(), 'target' => array() ) ) ),
		'ready-link-3'             	=> wp_kses( sprintf( __( '<a href="'.admin_url( 'customize.php' ).'" target="_blank">%s</a>', 'york-pro' ), 'Start Customizing' ), array( 'a' => array( 'href' => array(), 'target' => array() ) ) ),
	)
);

/**
 * Filter the child theme functions.php file.
 *
 * @param string $output Generated content.
 * @param string $slug Parent theme slug.
 */
function themebeans_generate_child_functions_php( $output, $slug ) {

	$slug_no_hyphens = strtolower( preg_replace( '#[^a-zA-Z]#', '', $slug ) );

	$output = "
		<?php
		/**
		 * Theme functions and definitions.
		 * This child theme was generated by Merlin WP.
		 *
		 * @link https://developer.wordpress.org/themes/basics/theme-functions/
		 *
		 * If your child theme has more than one .css file (eg. ie.css, style.css, main.css) then 
		 * you will have to make sure to maintain all of the parent theme dependencies.
		 *
		 * Make sure you're using the correct handle for loading the parent theme's styles.
		 * Failure to use the proper tag will result in a CSS file needlessly being loaded twice.
		 * This will usually not affect the site appearance, but it's inefficient and extends your page's loading time.
		 *
		 * @link https://codex.wordpress.org/Child_Themes
		 */

		/*
		 * Check if SCRIPT_DEBUG is set to true.
		 * If so, we’ll load the unminified versions of the main theme stylesheet.
		 * If not, load the compressed and combined version.
		 *
		 * @link https://codex.wordpress.org/WP_DEBUG
		 */
		function {$slug_no_hyphens}_child_enqueue_styles() {

		    if ( SCRIPT_DEBUG ) {
		        wp_enqueue_style( '{$slug}-style' , get_template_directory_uri() . '/style.css' );
		    } else {
		        wp_enqueue_style( '{$slug}-minified-style' , get_template_directory_uri() . '/style.min.css' );
		    }

		    wp_enqueue_style( '{$slug}-child-style',
		        get_stylesheet_directory_uri() . '/style.css',
		        array( '{$slug}-style' ),
		        wp_get_theme()->get('Version')
		    );
		}

		add_action(  'wp_enqueue_scripts', '{$slug_no_hyphens}_child_enqueue_styles' );\n
	";

	// Let's remove the tabs so that it displays nicely.
	$output = trim( preg_replace( '/\t+/', '', $output ) );

	// Filterable return.
	return $output;
}
add_filter( 'merlin_generate_child_functions_php', 'themebeans_generate_child_functions_php', 10, 2 );
